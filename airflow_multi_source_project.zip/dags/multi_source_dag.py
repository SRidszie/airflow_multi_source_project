import os, yaml
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from datetime import datetime

def resolve_path(task):
    if task['source_type'] == 'local':
        return os.path.join(os.path.dirname(__file__), "..", task['path'])
    return task['path']

def create_task(dag, task):
    path = resolve_path(task)
    if task['type'] == 'bash':
        return BashOperator(task_id=task['name'], bash_command=f"sh {path}", dag=dag)
    elif task['type'] == 'perl':
        return BashOperator(task_id=task['name'], bash_command=f"perl {path}", dag=dag)
    elif task['type'] == 'python':
        return BashOperator(task_id=task['name'], bash_command=f"python3 {path}", dag=dag)
    elif task['type'] == 'sql':
        return PostgresOperator(task_id=task['name'], postgres_conn_id=task['conn_id'], sql=open(path).read(), dag=dag)

config_file = os.path.join(os.path.dirname(__file__), "..", "config", "scripts_config.yaml")
with open(config_file) as f:
    config = yaml.safe_load(f)

with DAG("multi_source_dag", start_date=datetime(2025,7,30), schedule_interval=None, catchup=False) as dag:
    prev = None
    for task_conf in config['tasks']:
        t = create_task(dag, task_conf)
        if prev:
            prev >> t
        prev = t
